package com.example.SpotyBackUnir.Repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SpotyBackUnir.Entity.Artist;
public interface ArtistRepository extends JpaRepository<Artist, Long> {
    List<Artist> findByNameContainingIgnoreCase(String name);
}