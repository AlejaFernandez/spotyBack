package com.example.SpotyBackUnir.Controller;


import com.example.SpotyBackUnir.Entity.Song;
import com.example.SpotyBackUnir.Repository.SongRepository;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/songs")
@Api(value = "Song Controller", tags = {"Song Controller"})
public class SongController {

    @Autowired
    private SongRepository songRepository;

    @GetMapping
    @ApiOperation(value = "Get all songs", notes = "Retrieve a list of all songs")
    public List<Song> getAllSongs() {
        return songRepository.findAll();
    }

    @GetMapping("/{id}")
    @ApiOperation(value = "Get a song by ID", notes = "Busqueda de canciones  por ID")
    public ResponseEntity<Song> getSongById(@PathVariable Long id) {
        Optional<Song> song = songRepository.findById(id);
        return song.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    @ApiOperation(value = "Create a new song", notes = "Metodo de creación de nueva canción")
    public Song createSong(@RequestBody Song song) {
        return songRepository.save(song);
    }

    @PutMapping("/{id}")
    @ApiOperation(value = "Update a song", notes = "Metodo de actualización de canciones por  ID")
    public ResponseEntity<Song> updateSong(@PathVariable Long id, @RequestBody Song songDetails) {
        Optional<Song> song = songRepository.findById(id);
        if (song.isPresent()) {
            Song updatedSong = song.get();
            updatedSong.setTitle(songDetails.getTitle());
            updatedSong.setAlbum(songDetails.getAlbum());
            updatedSong.setDuration(songDetails.getDuration());
            return ResponseEntity.ok(songRepository.save(updatedSong));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    @ApiOperation(value = "Delete a song", notes = "Metodo para eliminar Cancion por ID")
    public ResponseEntity<Void> deleteSong(@PathVariable Long id) {
        Optional<Song> song = songRepository.findById(id);
        if (song.isPresent()) {
            songRepository.delete(song.get());
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/search")
    @ApiOperation(value = "Search songs by title", notes = "Metodo de busqueda de canción por titulo")
    public List<Song> searchSongsByTitle(@RequestParam String title) {
        return songRepository.findByTitleContainingIgnoreCase(title);
    }
}

