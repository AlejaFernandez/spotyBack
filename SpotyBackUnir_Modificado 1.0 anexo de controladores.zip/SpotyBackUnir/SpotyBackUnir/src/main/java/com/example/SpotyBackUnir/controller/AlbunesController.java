package com.example.SpotyBackUnir.controller;

import static com.example.SpotyBackUnir.services.AlbunesServices.SaveOrUpdate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpotyBackUnir.entity.Albunes;
import com.example.SpotyBackUnir.services.AlbunesServices;

@SuppressWarnings("unused")
@RestController
@RequestMapping(path = "api/Albunes")
public class AlbunesController<Nombre_del_album, ConsultarAlbum> {

    @Autowired
    private AlbunesServices albunesservices;

    @GetMapping
    public List<Albunes> getAll(){
        return albunesservices.getAlbunes();
    }

        @SuppressWarnings("unchecked")
        @GetMapping("/{Nombre_del_albumid}")
    public  ConsultarAlbum getAlbunes(@PathVariable("Nombre_del_albumid") Integer Nombre_del_albumid){
        return  (ConsultarAlbum) albunesservices.getAlbunes();
    }
    @PostMapping
    public void SaveOrUpdate(@RequestBody Nombre_del_album nombre_del_album ){
        AlbunesServices.SaveOrUpdate((Albunes) nombre_del_album);
    }
    @DeleteMapping("/{Nombre_del_albumid}")
    public void DeleteMapping(@PathVariable("Nombre_del_album") Integer Nombre_del_albumid ){
        AlbunesServices.delete(Nombre_del_albumid);
    }


    /**
     * @param albunesservices
     */
    public AlbunesController(AlbunesServices albunesservices) {
        this.albunesservices = albunesservices;

    }

}
