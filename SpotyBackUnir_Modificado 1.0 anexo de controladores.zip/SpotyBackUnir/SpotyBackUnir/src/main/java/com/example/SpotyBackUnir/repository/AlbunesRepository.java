package com.example.SpotyBackUnir.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.SpotyBackUnir.entity.Albunes;


@Repository

public interface AlbunesRepository extends JpaRepository < Albunes, Integer> {

}





