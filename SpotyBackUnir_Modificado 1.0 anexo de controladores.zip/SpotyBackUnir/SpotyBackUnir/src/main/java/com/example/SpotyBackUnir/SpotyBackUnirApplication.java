package com.example.SpotyBackUnir;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class SpotyBackUnirApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpotyBackUnirApplication.class, args);
	}

}
