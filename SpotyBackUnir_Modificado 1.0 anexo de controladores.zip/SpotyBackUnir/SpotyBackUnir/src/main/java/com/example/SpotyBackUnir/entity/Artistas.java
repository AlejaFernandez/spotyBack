package com.example.SpotyBackUnir.entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
public class Artistas {
    @Id 
    public int Nombre;
    public String Apellido ;
}
