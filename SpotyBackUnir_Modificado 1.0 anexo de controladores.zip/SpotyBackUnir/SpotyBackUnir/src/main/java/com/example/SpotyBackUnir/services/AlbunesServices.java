package com.example.SpotyBackUnir.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SpotyBackUnir.entity.Albunes;
import com.example.SpotyBackUnir.repository.AlbunesRepository;

import java.util.List;
import java.util.Optional;


@Service
public class AlbunesServices {

    @Autowired
    static
    AlbunesRepository AlbunesRepository  ;

    public List<Albunes> getAlbunes() {
        return AlbunesRepository.findAll();
    }

    public Optional<Albunes> getAlbunes(Integer Id) {
        return AlbunesRepository.findById(Id);
    }
public static void SaveOrUpdate(Albunes albunes)  {
    
    AlbunesRepository.save(albunes);
}

public static void delete(Integer Id)  {
    
    AlbunesRepository.deleteById(Id);
}

}
