package com.example.SpotyBackUnir;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpotyBackUnirApplicationTests {

	@Test
	void contextLoads() {
	}

}
